# Credit Risk Prediction — Final Report

## Dataset
- Source file: F:\Datas\AI_Course\Soft_Skill\4 Module\Dataset\archive\credit_risk_dataset.csv
- Shape: (32581, 12)

## Preprocessing
- Numeric imputation (median) and scaling.
- Categorical imputation and ordinal encoding.

## Models Trained
- random_forest: ROC_AUC=0.9313, F1=0.8174
- xgboost: ROC_AUC=0.9458, F1=0.8321
- lightgbm: ROC_AUC=0.9482, F1=0.8300

**Selected best model:** lightgbm

## SHAP
- Global SHAP summary plot included.
- SHAP dependence plots for top 3 features included.
- Local explanations (true_positive, true_negative, false_positive) included.

## Interpretation
SHAP analysis provides both global and local interpretability to support lending decisions.

## Conclusion and Recommendations
Use model probabilities and SHAP explanations to create explainable decision workflows for loan approvals.
